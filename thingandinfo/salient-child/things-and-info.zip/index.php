<?php include 'inc/header.php'?>

<section class="main_wrapper">
        <div class="main_col_left">
            <a href="#!" class="logo_box">
                <img src="assets/front/images/logo-main.png" alt="logo" class="img_fluid">
            </a>
            <div class="nav_wrapper">
                <div class="nav_bar">
                    <ul>
                        <li class="drop_dwon_nav">
                            <a href="#!"> <img src="assets/front/images/nav-icon-1.png" alt="icon">Storage</a>
                        </li>
                        <ul class="drop_dwon_list">
                            <li>
                                <a href="#!"> <img src="assets/front/images/table-icon-1.png" alt="icon">Defect images</a>
                            </li>
                            <li>
                                <a href="#!"> <img src="assets/front/images/table-icon-1.png" alt="icon">Assets</a>
                            </li>
                            <li>
                                <a href="#!"> <img src="assets/front/images/table-icon-1.png" alt="icon">UI files</a>
                            </li>
                            <li>
                                <a href="#!"> <img src="assets/front/images/table-icon-1.png" alt="icon">Documentation</a>
                            </li>
                            <li>
                                <a href="#!"> <img src="assets/front/images/table-icon-1.png" alt="icon">Starred</a>
                            </li>
                        </ul>
                        <li>
                            <a href="#!"> <img src="assets/front/images/nav-icon-2.png" alt="icon">Starred</a>
                        </li>
                        <li>
                            <a href="#!"> <img src="assets/front/images/nav-icon-3.png" alt="icon">Statistics</a>
                        </li>
                        <li>
                            <a href="#!"> <img src="assets/front/images/nav-icon-4.png" alt="icon">Setting</a>
                        </li>
                    </ul>
                </div>
                <div class="storage_indicator">
                    <div class="top_head">
                        <img src="assets/front/images/storage_icon.png" alt="img">
                        <p class="title">My Storage</p>

                    </div>
                    <div class="storage_bar">
                        <div class="storage_progress" style="width: 30%;"></div>
                    </div>
                    <p class="desc">You have used 5 GB out of 15 GB.</p>
                </div>
            </div>
        </div>
        <div class="main_col_middle">
            <div class="header_main">
                <div class="left_col">
                    <h1 class="page_title"><img src="assets/front/images/drive-icon.png" alt="img">Storage</h1>
                    <p>Recent</p>
                </div>

                <div class="right_col">
                    <div class="inner_col">
                        <div class="search_bar">
                            <input type="search" placeholder="Search here...">
                            <img src="assets/front/images/search.png" alt="img" class="seach_icon">
                        </div>

                        <div class="profile_info_top">
                            <p class="name_logo">AH</p>
                            <p class="user_name">Akhsan Hakiki</p>
                            <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                        </div>
                    </div>

                    <label for="upload_main" class="upload_btn_top">
                         <svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21" fill="none">
                            <path d="M15.8333 11.3333H10.8333V16.3333H9.16666V11.3333H4.16666V9.66666H9.16666V4.66666H10.8333V9.66666H15.8333V11.3333Z" fill="#F9FAFB"/>
                        </svg>
                        Upload File
                        <input type="file" id="upload_main" style="display: none;">
                    </label>
                </div>
            </div>
            <div class="main_content_wrapper">
                <div class="top_card_row">
                    <a href="#!" class="gen_card">
                        <p class="card_title"><img src="assets/front/images/img-icon.png" alt="img">Rating UI design.svg</p>
                        <div class="img_box">
                            <img src="assets/front/images/card-img-1.png" alt="img" class="img_fluid">
                        </div>
                    </a>
                    <a href="#!" class="gen_card">
                        <p class="card_title"><img src="assets/front/images/img-icon.png" alt="img">Rating UI design.svg</p>
                        <div class="img_box">
                            <img src="assets/front/images/card-img-2.png" alt="img" class="img_fluid">
                        </div>
                    </a>
                    <a href="#!" class="gen_card">
                        <p class="card_title"><img src="assets/front/images/img-icon.png" alt="img">Rating UI design.svg</p>
                        <div class="img_box">
                            <img src="assets/front/images/card-img-3.png" alt="img" class="img_fluid">
                        </div>
                    </a>
                    <a href="#!" class="gen_card">
                        <p class="card_title"><img src="assets/front/images/img-icon.png" alt="img">Rating UI design.svg</p>
                        <div class="img_box">
                            <img src="assets/front/images/card-img-4.png" alt="img" class="img_fluid">
                        </div>
                    </a>
                    <a href="#!" class="gen_card">
                        <p class="card_title"><img src="assets/front/images/img-icon.png" alt="img">Rating UI design.svg</p>
                        <div class="img_box">
                            <img src="assets/front/images/card-img-5.png" alt="img" class="img_fluid">
                        </div>
                    </a>
                </div>

                <h2 class="gen_title">My Files</h2>
                <div class="table_wrapper">
                    <table id="myTable" class="hover" style="width:100%">
                        <thead>
                            <tr>
                                <th>Asset Name</th>
                                <th>Tag</th>
                                <th>Created</th>
                                <th>Owner</th>
                                <th>Last Modified</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon"><img src="assets/front/images/table-icon-1.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon">SA</span>
                                      <span>Shuichi Akai</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon"><img src="assets/front/images/table-icon-1.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon">SA</span>
                                      <span>Shuichi Akai</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon"><img src="assets/front/images/table-icon-1.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon name_icon_color_4">SA</span>
                                      <span>Shuichi Akai</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon"><img src="assets/front/images/table-icon-1.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon">SA</span>
                                      <span>Shuichi Akai</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon icon_color_1"><img src="assets/front/images/table-icon-2.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon name_icon_color_1">FR</span>
                                      <span>Furuya Rei</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon icon_color_2"><img src="assets/front/images/table-icon-3.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon name_icon_color_2">FR</span>
                                      <span>Furuya Rei</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon icon_color_3"><img src="assets/front/images/table-icon-4.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon name_icon_color_3">FR</span>
                                      <span>Furuya Rei</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon icon_color_4"><img src="assets/front/images/table-icon-5.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon name_icon_color_3">FR</span>
                                      <span>Furuya Rei</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon"><img src="assets/front/images/table-icon-1.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon">SA</span>
                                      <span>Shuichi Akai</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon"><img src="assets/front/images/table-icon-1.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon">SA</span>
                                      <span>Shuichi Akai</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon"><img src="assets/front/images/table-icon-1.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon name_icon_color_4">SA</span>
                                      <span>Shuichi Akai</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon"><img src="assets/front/images/table-icon-1.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon">SA</span>
                                      <span>Shuichi Akai</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon icon_color_1"><img src="assets/front/images/table-icon-2.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon name_icon_color_1">FR</span>
                                      <span>Furuya Rei</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon icon_color_2"><img src="assets/front/images/table-icon-3.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon name_icon_color_2">FR</span>
                                      <span>Furuya Rei</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon icon_color_3"><img src="assets/front/images/table-icon-4.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon name_icon_color_3">FR</span>
                                      <span>Furuya Rei</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                            <tr>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="table_icon icon_color_4"><img src="assets/front/images/table-icon-5.png" alt="img"></span>
                                      <span>Defect images</span>
                                    </div>
                                </td>
                                <td>#defect</td>
                                <td>12 Feb 2022</td>
                                <td> 
                                    <div class="flex_wrap">
                                      <span class="name_icon name_icon_color_3">FR</span>
                                      <span>Furuya Rei</span>
                                    </div>
                                </td>
                                <td>1 days ago</td>
                                <td>
                                    <button class="profile_info_dropdown_btn"><img src="assets/front/images//Btn-Option-Light.png" alt="img"></button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="main_col_right">
            <h2 class="right_header_top_text">3d credit card .jpg</h2>

            <div class="file_details_listing">
                <p class="list_heading">File Detail</p>
                <div class="list_scroller">
                    <div class="list_inner_wrap">
                        <p class="list_sub_heading">Location</p>
                        <p class="list_info">My Files</p>
                    </div>

                    <div class="list_inner_wrap">
                        <p class="list_sub_heading">Type</p>
                        <p class="list_info">Image</p>
                    </div>

                    <div class="list_inner_wrap">
                        <p class="list_sub_heading">Size</p>
                        <p class="list_info">1.8 MB</p>
                    </div>

                    <div class="list_inner_wrap">
                        <p class="list_sub_heading">Owner</p>
                        <p class="list_info flex_wrap"><span class="name_icon">FR</span> Furuya Rei</p>
                    </div>
                </div>
                <div class="list_inner_wrap">
                    <p class="list_sub_heading">Modified</p>
                    <p class="list_info">13 Mar 2022 by Furuya Rei</p>
                </div>
                <div class="list_inner_wrap">
                    <p class="list_sub_heading">Created</p>
                    <p class="list_info">1.2 MB</p>
                </div>
            </div>

            <button class="close_info_btn">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="25" viewBox="0 0 24 25" fill="none">
                  <path d="M19 6.91L17.59 5.5L12 11.09L6.41 5.5L5 6.91L10.59 12.5L5 18.09L6.41 19.5L12 13.91L17.59 19.5L19 18.09L13.41 12.5L19 6.91Z" fill="black"/>
              </svg>
           </button>
        </div>
    </section>



<?php include 'inc/footer.php'?>